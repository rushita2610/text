const Homescreen_Api = 'https://reapp.com.gh/wp-json/wp/v2/home-api';
const Login_Api ='https://reapp.com.gh/wp-json/jwt-auth/v1/token';
const Forgotpassword = 'https://reapp.com.gh/wp-content/themes/classiads-child/template-forget-password-api.php';