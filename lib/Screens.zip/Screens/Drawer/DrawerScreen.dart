import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


import '../../ColorConstant/ColorConstant.dart';
import '../BlogWebViewScreen/WebViewscreen.dart';
import '../BottomNavigationBarScreen/BottomNavigationScreen.dart';
import '../Login/Contactus.dart';
import '../Login/FAQ.dart';
import '../Login/LoginScreen.dart';
import '../Login/Sellerregistration.dart';
import '../Login/UserReg.dart';
import '../Policies/About Us.dart';
import '../Policies/PrivacyPolicy.dart';
import '../Policies/T & C.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({Key? key}) : super(key: key);

  @override
  State<DrawerScreen> createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  List<IconData> menuicon = [
    CupertinoIcons.house_fill,
    Icons.login_outlined,
    CupertinoIcons.arrow_right_to_line,
    CupertinoIcons.arrow_right_to_line,
    CupertinoIcons.exclamationmark,
    Icons.add_call,
    Icons.question_mark,
    Icons.file_copy_outlined,
    Icons.file_copy_outlined,
    Icons.local_police_rounded,
  ];

  List<dynamic> menuname = [
    "Home",
    "Login",
    "Seller Registration",
    "General User Registration",
    "About us",
    "Contact us",
    "FAQ",
    "Blog",
    "Terms and Conditions",
    "Privacy Policy",
  ];

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Drawer(
      backgroundColor: CupertinoColors.systemGrey5,
      child: ListView(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.only(left: 18, right: 18),
            //height: height * 0.7,
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    // Navigator.of(context).push(
                    //   MaterialPageRoute(builder: (context) {
                    //     return const EditProfile();
                    //   }),
                    // );
                  },
                  child: Container(
                    height: height * 0.1,
                    width: width,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          height: height * 0.07,
                          width: width * 0.15,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(50),
                            child: Image.asset(
                              "assets/images/user.png",
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 25,
                        ),
                        Container(
                          height: 20,
                          child: const Text(
                            "Guest Login",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: colorblack,
                              //fontWeight: FontWeight.w300,
                              fontFamily: "assets/fonts/Raleway-Thin.ttf",
                              fontSize: 17,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 15,
                ),
                const Divider(
                  thickness: 1.5,
                  color: maincolor,
                ),
                Container(
                  height: menuicon.length * 43,
                  child: ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: menuicon.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        height: 43,
                        // width: 200,
                        child: InkWell(
                          onTap: () async {
                            if (menuname[index] == "Home") {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) {
                                  return const BottomNavigationScreen(0);
                                }),
                              );
                            } else if (menuname[index] == "Login") {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) {
                                  return const LoginScreen();
                                }),
                              );
                            } else if (menuname[index] ==
                                "Seller Registration") {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) {
                                  return const SellerReg();
                                }),
                              );
                              // GetNotification_ApiCall();
                            } else if (menuname[index] ==
                                "General User Registration") {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) {
                                  return const UserReg();
                                }),
                              );
                            } else if (menuname[index] == "About us") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const Aboutus(),
                                ),
                              );
                            } else if (menuname[index] == "Contact us") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const Contactus(),
                                ),
                              );
                            } else if (menuname[index] == "FAQ") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const FAQ(),
                                ),
                              );
                            } else if (menuname[index] == "Blog") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const Webviewscreen(),
                                ),
                              );
                            } else if (menuname[index] ==
                                "Terms and Conditions") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const termscondition(),
                                ),
                              );
                            } else if (menuname[index] == "Privacy Policy") {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const privacypolicy(),
                                ),
                              );
                            }
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                alignment: Alignment.topCenter,
                                padding: const EdgeInsets.all(5),
                                height: 30,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: drawericon,
                                ),
                                child: Center(
                                  child: Icon(
                                    menuicon[index],
                                    color: Colors.white,
                                    size: 15,
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Container(
                                width: width * 0.5,
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  menuname[index],
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                      fontSize: 15,
                                      color: colorblack,
                                      //fontWeight: FontWeight.w300,
                                      fontFamily:
                                          "assets/fonts/Raleway-Thin.ttf"),
                                ),
                              ),
                              const Divider(
                                thickness: 1.5,
                                color: Colors.grey,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
