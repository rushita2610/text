import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../Api/api.dart';
import '../../ColorConstant/ColorConstant.dart';
import '../BottomNavigationBarScreen/BottomNavigationScreen.dart';
import '../ProductsScreen/AllProductsScreen.dart';
import 'package:http/http.dart' as http;


class Subcategory extends StatefulWidget {
  const Subcategory({Key? key}) : super(key: key);

  @override
  State<Subcategory> createState() => _SubcategoryState();
}

class _SubcategoryState extends State<Subcategory> {
  bool isReload = false;
  List<dynamic> subcategory = [
    {
      'name': 'Soccer Jerseys',
      'QTY': 67,
    },
    {
      'name': 'Black Stars Jerseys',
      'QTY': 11,
    },
    {
      'name': 'Footballs',
      'QTY': 20,
    },
    {
      'name': 'Ladies Gym Wear',
      'QTY': 31,
    },
    {
      'name': 'Sports Bra',
      'QTY': 35,
    },
    {
      'name': 'Gym Equipment',
      'QTY': 167,
    },
    {
      'name': 'Dumbbells',
      'QTY': 13,
    },
    {
      'name': 'Board Games',
      'QTY': 9,
    },
    {
      'name': 'Female Jersey',
      'QTY': 2,
    },
    {
      'name': 'Swimming Pools',
      'QTY': 5,
    },
    {
      'name': 'Camping Tents',
      'QTY': 8,
    },
    {
      'name': 'Electric Scooters',
      'QTY': 12,
    },
    {
      'name': 'Tenniis Rackets',
      'QTY': 7,
    },
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   // HomeScreen_APIcall();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return SafeArea(
      child: Scaffold(
        backgroundColor: CupertinoColors.systemGrey5,
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_outlined,
              color: maincolor,
            ),
          ),
          title: Transform(
            transform: Matrix4.translationValues(-10, 0, 0),
            child: const Text(
              "Sports and Recreation",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          backgroundColor: CupertinoColors.systemGrey5,
          elevation: 0,
          // centerTitle: true,
        ),
        body: (isReload == false)
            ? SingleChildScrollView(
                child: Container(
                  //color: Colors.red,
                  padding: const EdgeInsets.all(15),
                  // height: height,
                  child: Column(
                    children: [
                      Flexible(
                        flex: 0,
                        child: Container(
                         // color: Colors.red,
                          height: subcategory.length * 48,
                          width: width,
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                           // scrollDirection: ,
                              itemCount: subcategory.length,
                              itemBuilder: (BuildContext cntx, int index) {
                                return Container(
                                  height: height * 0.06,
                                  child: Column(
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  const AllProducts(),
                                            ),
                                          );
                                        },
                                        child: Container(
                                          width: width,
                                          padding:
                                              const EdgeInsets.only(right: 5),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                "${subcategory[index]['name']}  (${subcategory[index]['QTY']})",
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 17,
                                                ),
                                              ),
                                              const Icon(
                                                Icons.arrow_forward_ios_rounded,
                                                color: maincolor,
                                                size: 20,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      const Divider(
                                        thickness: 1,
                                        color: Colors.grey,
                                      )
                                    ],
                                  ),
                                );
                              }),
                        ),
                      ),
                      Container(
                         height: 50,
                         width: width/1-100,
                        //color: Colors.red,
                        child: RaisedButton(
                          elevation: 0,
                          color: maincolor,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const AllProducts(),
                              ),
                            );
                          },
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          child: const Text(
                            'View all',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            : const Center(
                child: CircularProgressIndicator(
                  color: maincolor,
                ),
              ),
      ),
    );
  }

  HomeScreen_APIcall() async {
    setState(() {
      isReload = true;
    });
    try {
      //   var response = await http.post(Uri.parse(login), body: body);
      var response = await http.get(Uri.parse(Homescreen_Api));
      if (response.statusCode == 200) {
        var decode = jsonDecode(response.body);

        print("decode${decode}");
        // print(" Data ${categories = decode["categories"]}");
        // categories.clear();
        // categories = decode["categories"];
        subcategory.clear();
        subcategory = decode[""];



        // if (decode["success"] == true) {
        //   setState(() {
        //     print("decode data${decode}");
        //     categories.clear();
        //     categories = decode["categories"];
        //     // print("decode data${decode}");
        //   });
        // } else {}

        setState(() {
          isReload = false;
        });
      } else {
        print("Error" + response.statusCode.toString());
        print("Error" + response.body.toString());
      }
    } catch (e) {
      setState(() {
        isReload = false;
      });
      print("Exception in Today Attendance=>" + e.toString());
      throw e;
    }
  }
}
