import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../ColorConstant/ColorConstant.dart';
import '../CategoriesScreen/CategoriesScreen.dart';
import '../Drawer/DrawerScreen.dart';
import '../HomeScreen/HomeScreen.dart';
import '../Search/SearchScreen.dart';

class BottomNavigationScreen extends StatefulWidget {
  final int _selectedIndex;

  const BottomNavigationScreen(this._selectedIndex, {super.key});

  @override
  _BottomNavigationScreenState createState() =>
      _BottomNavigationScreenState(_selectedIndex);
}

class _BottomNavigationScreenState extends State<BottomNavigationScreen>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 1;
  AnimationController? _controller;

  // ignore: non_constant_identifier_names
  DateTime pre_backpress = DateTime.now();

  final List<Widget> _widgetOptions = <Widget>[
    // LoginScreen(),
    const HomeScreen(),
    const SearchScreen(),
    const CategoriesScreen(),
    const DrawerScreen(),
  ];

  List<IconData> BottomList = [
    CupertinoIcons.house_fill,
    CupertinoIcons.search,
    CupertinoIcons.book_fill,
    Icons.more_horiz_rounded,
  ];
  List<dynamic> Bottomname = [
    "Home",
    "Search",
    "Categories",
    "More",
  ];

  _BottomNavigationScreenState(this._selectedIndex);

  bool select = false;

  bool select1 = false;

  bool select2 = false;

  bool select3 = false;

  bool select4 = false;

  @override
  void initState() {
    _controller = AnimationController(vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    DateTime timeBackPressed = DateTime.now();
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return WillPopScope(
      onWillPop: () async {
        final timegap = DateTime.now().difference(pre_backpress);
        final cantExit = timegap >= const Duration(seconds: 2);
        pre_backpress = DateTime.now();
        if (cantExit) {
          //show snackbar
          const snack = SnackBar(
            content: Text('Press Back button again to Exit'),
            duration: Duration(seconds: 2),
          );
          ScaffoldMessenger.of(context).showSnackBar(snack);
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
        backgroundColor: CupertinoColors.systemGrey5,
        extendBody: true,
        bottomNavigationBar: Container(
          color: Colors.transparent,
          height: height * 0.06,
          padding: const EdgeInsets.only(bottom: 0.0),
          alignment: Alignment.bottomCenter,
          child: Stack(
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: 0,
                child: Container(
                  color: Colors.red,
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                child: Container(
                  color: Colors.transparent,
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisSpacing: 5,
                      mainAxisSpacing: 5,
                      childAspectRatio: 1 / 0.60,
                      crossAxisCount: 4,
                    ),
                    shrinkWrap: true,
                    itemCount: _widgetOptions.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                        child: Column(
                          children: [
                            Container(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                child: Icon(
                                  BottomList[index],
                                  size: 25,
                                  color: (_selectedIndex == index)
                                      ? maincolor
                                      : Colors.black54,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 3,
                            ),
                            Container(
                              height: 15,
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                child: Text(
                                  Bottomname[index],
                                  style: TextStyle(
                                    color: (_selectedIndex == index)
                                        ? maincolor
                                        : Colors.black54,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        body: _widgetOptions.elementAt(_selectedIndex),
      ),
    );
  }
}
